//
//  ViewControllerMenu.swift
//  Project App
//
//  Created by Adrian Schlegel on 18.03.22.
//

import UIKit

@MainActor class ViewControllerMenu: UIViewController {
    
    override func viewDidLoad() {
        
    }
    
    
}
